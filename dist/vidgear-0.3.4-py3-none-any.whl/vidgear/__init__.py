from .version import __version__

__author__ = "Abhishek Thakur (@abhiTronix) <abhi.una12@gmail.com>"
